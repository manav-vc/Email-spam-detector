"""
Deploy the trained Email Spam Detector to Amazon SageMaker.

Pipeline:
    1. Tar the trained pipeline (spam_pipeline.joblib) into model.tar.gz
    2. Upload model.tar.gz to S3
    3. Create a SageMaker SKLearnModel pointing at that artifact
    4. Deploy to a real-time inference endpoint (ml.t2.medium by default)

Prerequisites:
    - AWS credentials configured (aws configure / IAM role)
    - A SageMaker execution role ARN
    - sagemaker and boto3 Python SDKs installed

Usage:
    python deploy.py \
        --role-arn arn:aws:iam::ACCOUNT_ID:role/SageMakerExecutionRole \
        --bucket  my-spam-detector-bucket \
        --region  us-east-1
"""

import argparse
import os
import tarfile

import boto3
import sagemaker
from sagemaker.sklearn.model import SKLearnModel


def package_model(model_path: str, output_tar: str) -> str:
    """Tar.gz the model artifact the way SageMaker expects it."""
    os.makedirs(os.path.dirname(output_tar) or ".", exist_ok=True)
    with tarfile.open(output_tar, "w:gz") as tar:
        tar.add(model_path, arcname=os.path.basename(model_path))
    print(f"Packaged model -> {output_tar}")
    return output_tar


def upload_to_s3(tar_path: str, bucket: str, key: str, region: str) -> str:
    """Upload the tarball to S3 and return the s3:// URI."""
    s3 = boto3.client("s3", region_name=region)
    s3.upload_file(tar_path, bucket, key)
    uri = f"s3://{bucket}/{key}"
    print(f"Uploaded artifact -> {uri}")
    return uri


def deploy(model_uri: str, role: str, region: str, endpoint_name: str, instance: str) -> None:
    """Create and deploy a SageMaker SKLearn model endpoint."""
    session = sagemaker.Session(boto_session=boto3.Session(region_name=region))

    sk_model = SKLearnModel(
        model_data=model_uri,
        role=role,
        entry_point="inference.py",
        source_dir=".",            # ships inference.py + requirements.txt
        framework_version="1.2-1", # sklearn version on the container
        py_version="py3",
        sagemaker_session=session,
    )

    print(f"Deploying endpoint '{endpoint_name}' on {instance} ...")
    predictor = sk_model.deploy(
        initial_instance_count=1,
        instance_type=instance,
        endpoint_name=endpoint_name,
    )
    print(f"\nEndpoint deployed: {predictor.endpoint_name}")
    print("You can now invoke it via boto3 / the Lambda function.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="../model/spam_pipeline.joblib",
                        help="Local path to the trained joblib pipeline.")
    parser.add_argument("--role-arn", required=True,
                        help="SageMaker execution role ARN.")
    parser.add_argument("--bucket", required=True,
                        help="S3 bucket to upload the model tarball.")
    parser.add_argument("--prefix", default="spam-detector",
                        help="S3 key prefix.")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--endpoint-name", default="spam-detector-endpoint")
    parser.add_argument("--instance-type", default="ml.t2.medium")
    args = parser.parse_args()

    tar_path = "build/model.tar.gz"
    package_model(args.model_path, tar_path)

    model_uri = upload_to_s3(
        tar_path=tar_path,
        bucket=args.bucket,
        key=f"{args.prefix}/model.tar.gz",
        region=args.region,
    )

    deploy(
        model_uri=model_uri,
        role=args.role_arn,
        region=args.region,
        endpoint_name=args.endpoint_name,
        instance=args.instance_type,
    )


if __name__ == "__main__":
    main()
